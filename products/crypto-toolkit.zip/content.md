# Crypto Trading Toolkit

**Senales, analisis y bots para operar en mercados crypto con ventaja estrategica**

---

## Contenido

1. Analisis Tecnico
2. Estrategias de Trading
3. Backtesting
4. Gestion de Riesgo
5. Bots de Trading
6. Market Intelligence
7. Portfolio Management
8. Herramientas de Analisis

---

## 1. Analisis Tecnico

### 1.1 Multi-Indicator Scanner

Escanea multiples pares y timeframes detectando oportunidades.

```python
#!/usr/bin/env python3
"""
Multi-Indicator Scanner - Escanea pares crypto en busca de senales
"""
import pandas as pd
import numpy as np
import requests
from datetime import datetime, timedelta
import json

class CryptoScanner:
    def __init__(self, base_url="https://api.binance.com"):
        self.api = base_url
        self.session = requests.Session()
    
    def get_klines(self, symbol: str, interval: str = "1h", limit: int = 100) -> pd.DataFrame:
        """Obtiene velas OHLCV de Binance"""
        url = f"{self.api}/api/v3/klines"
        params = {"symbol": symbol, "interval": interval, "limit": limit}
        resp = self.session.get(url, params=params)
        resp.raise_for_status()
        
        data = resp.json()
        df = pd.DataFrame(data, columns=[
            "timestamp", "open", "high", "low", "close", "volume",
            "close_time", "quote_vol", "trades", "taker_buy_base",
            "taker_buy_quote", "ignore"
        ])
        for col in ["open", "high", "low", "close", "volume"]:
            df[col] = pd.to_numeric(df[col])
        df["time"] = pd.to_datetime(df["timestamp"], unit="ms")
        return df
    
    def rsi(self, prices: pd.Series, period: int = 14) -> pd.Series:
        """Calcula RSI"""
        delta = prices.diff()
        gain = delta.clip(lower=0)
        loss = -delta.clip(upper=0)
        avg_gain = gain.rolling(window=period, min_periods=period).mean()
        avg_loss = loss.rolling(window=period, min_periods=period).mean()
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def macd(self, prices: pd.Series, fast=12, slow=26, signal=9):
        """Calcula MACD"""
        ema_fast = prices.ewm(span=fast).mean()
        ema_slow = prices.ewm(span=slow).mean()
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=signal).mean()
        histogram = macd_line - signal_line
        return macd_line, signal_line, histogram
    
    def bollinger_bands(self, prices: pd.Series, period=20, std_dev=2):
        """Calcula Bandas de Bollinger"""
        sma = prices.rolling(window=period).mean()
        std = prices.rolling(window=period).std()
        upper = sma + (std * std_dev)
        lower = sma - (std * std_dev)
        return upper, sma, lower
    
    def scan(self, symbols: list, interval: str = "1h") -> list:
        """Escanea lista de simbolos buscando senales"""
        signals = []
        
        for symbol in symbols:
            try:
                df = self.get_klines(symbol, interval, limit=100)
                close = df["close"]
                
                # Calcular indicadores
                rsi_val = self.rsi(close).iloc[-1]
                macd_line, signal_line, hist = self.macd(close)
                upper, middle, lower = self.bollinger_bands(close)
                
                current_price = close.iloc[-1]
                
                # Detectar senales
                signal_flags = []
                
                if rsi_val < 30:
                    signal_flags.append("SOBREVENDIDO")
                elif rsi_val > 70:
                    signal_flags.append("SOBRECOMPRADO")
                
                if hist.iloc[-1] > 0 and hist.iloc[-2] < 0:
                    signal_flags.append("MACD_BULLISH_CROSS")
                elif hist.iloc[-1] < 0 and hist.iloc[-2] > 0:
                    signal_flags.append("MACD_BEARISH_CROSS")
                
                if current_price <= lower.iloc[-1]:
                    signal_flags.append("BB_TOUCH_LOWER")
                elif current_price >= upper.iloc[-1]:
                    signal_flags.append("BB_TOUCH_UPPER")
                
                if signal_flags:
                    signals.append({
                        "symbol": symbol,
                        "price": current_price,
                        "rsi": round(rsi_val, 1),
                        "signals": signal_flags,
                        "time": datetime.now().isoformat()
                    })
                
            except Exception as e:
                print(f"  Error scanning {symbol}: {e}")
        
        return signals


# Uso
# scanner = CryptoScanner()
# signals = scanner.scan(["BTCUSDT", "ETHUSDT", "SOLUSDT"])
# print(json.dumps(signals, indent=2))
```

### 1.2 Order Book Analyzer

Analiza el libro de ordenes para detectar soportes y resistencias.

```python
#!/usr/bin/env python3
"""
Order Book Analyzer - Analiza profundidad de mercado y niveles clave
"""
import requests
import pandas as pd
import numpy as np

class OrderBookAnalyzer:
    def __init__(self, base_url="https://api.binance.com"):
        self.api = base_url
    
    def get_orderbook(self, symbol: str, limit: int = 100) -> dict:
        """Obtiene el libro de ordenes"""
        url = f"{self.api}/api/v3/depth"
        resp = requests.get(url, params={"symbol": symbol, "limit": limit})
        return resp.json()
    
    def analyze(self, symbol: str, levels: int = 20):
        """Analiza el libro de ordenes y detecta niveles clave"""
        data = self.get_orderbook(symbol)
        
        bids = pd.DataFrame(data["bids"], columns=["price", "volume"], dtype=float)
        asks = pd.DataFrame(data["asks"], columns=["price", "volume"], dtype=float)
        
        # Calcular clusters de volumen
        bins = np.linspace(min(bids["price"].min(), asks["price"].min()),
                          max(bids["price"].max(), asks["price"].max()), 50)
        
        bid_clusters = pd.cut(bids["price"], bins).value_counts().sort_index()
        ask_clusters = pd.cut(asks["price"], bins).value_counts().sort_index()
        
        # Calcular support/resistance levels
        mid = (asks["price"].min() + bids["price"].max()) / 2
        bid_volume = bids["volume"].sum()
        ask_volume = asks["volume"].sum()
        ratio = bid_volume / ask_volume if ask_volume > 0 else float('inf')
        
        # Detectar paredes de compra/venta
        big_bids = bids[bids["volume"] > bids["volume"].quantile(0.9)]
        big_asks = asks[asks["volume"] > asks["volume"].quantile(0.9)]
        
        return {
            "symbol": symbol,
            "mid_price": mid,
            "bid_ask_ratio": round(ratio, 3),
            "total_bid_vol": round(bid_volume, 2),
            "total_ask_vol": round(ask_volume, 2),
            "support_zones": big_bids.head(5).to_dict("records"),
            "resistance_zones": big_asks.head(5).to_dict("records"),
            "imbalance": "BUY" if ratio > 1.2 else ("SELL" if ratio < 0.8 else "NEUTRAL")
        }
```

---

## 2. Estrategias de Trading

### 2.1 Estrategia: Golden Cross / Death Cross

Estrategia basada en cruce de medias moviles.

```python
def golden_cross_strategy(df: pd.DataFrame, fast=50, slow=200):
    """Golden Cross: comprar cuando MA fast cruza arriba MA slow"""
    df["ma_fast"] = df["close"].rolling(fast).mean()
    df["ma_slow"] = df["close"].rolling(slow).mean()
    df["signal"] = 0
    
    # Senal de compra: MA fast cruza arriba MA slow
    df.loc[(df["ma_fast"] > df["ma_slow"]) & 
           (df["ma_fast"].shift(1) <= df["ma_slow"].shift(1)), "signal"] = 1
    
    # Senal de venta: MA fast cruza abajo MA slow
    df.loc[(df["ma_fast"] < df["ma_slow"]) & 
           (df["ma_fast"].shift(1) >= df["ma_slow"].shift(1)), "signal"] = -1
    
    return df

def rsi_mean_reversion(df: pd.DataFrame, oversold=30, overbought=70):
    """RSI Mean Reversion: comprar sobrevendido, vender sobrecomprado"""
    delta = df["close"].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    
    avg_gain = gain.rolling(14).mean()
    avg_loss = loss.rolling(14).mean()
    rs = avg_gain / avg_loss
    df["rsi"] = 100 - (100 / (1 + rs))
    
    df["signal"] = 0
    df.loc[df["rsi"] < oversold, "signal"] = 1        # Comprar
    df.loc[df["rsi"] > overbought, "signal"] = -1      # Vender
    return df

def bollinger_squeeze(df: pd.DataFrame, period=20):
    """Bollinger Squeeze: comprar cuando precio toca banda inferior"""
    df["sma"] = df["close"].rolling(period).mean()
    df["std"] = df["close"].rolling(period).std()
    df["upper"] = df["sma"] + (df["std"] * 2)
    df["lower"] = df["sma"] - (df["std"] * 2)
    df["bb_width"] = df["upper"] - df["lower"]
    
    df["signal"] = 0
    df.loc[df["close"] < df["lower"], "signal"] = 1     # Comprar
    df.loc[df["close"] > df["upper"], "signal"] = -1    # Vender
    
    # Squeeze detection (low volatility -> expansion coming)
    df["squeeze"] = df["bb_width"] < df["bb_width"].rolling(20).quantile(0.1)
    return df
```

---

## 3. Backtesting

### 3.1 Complete Backtesting Framework

Framework completo para probar estrategias con datos historicos.

```python
#!/usr/bin/env python3
"""
Backtesting Framework - Prueba estrategias con datos historicos reales
"""
import pandas as pd
import numpy as np
from typing import Callable, Dict
from datetime import datetime

class Backtester:
    def __init__(self, initial_capital: float = 10000, commission: float = 0.001):
        self.initial_capital = initial_capital
        self.commission = commission
        self.results = None
    
    def run(self, df: pd.DataFrame, strategy_fn: Callable, strategy_params: dict = None) -> Dict:
        """Ejecuta backtest de una estrategia"""
        data = df.copy()
        
        # Generar senales
        if strategy_params:
            data = strategy_fn(data, **strategy_params)
        else:
            data = strategy_fn(data)
        
        # Simular trades
        capital = self.initial_capital
        position = 0
        trades = []
        equity_curve = []
        
        for i in range(1, len(data)):
            signal = data["signal"].iloc[i]
            price = data["close"].iloc[i]
            date = data.index[i] if isinstance(data.index, pd.DatetimeIndex) else i
            
            if signal == 1 and capital > 0:
                # Comprar
                shares = (capital * (1 - self.commission)) / price
                cost = shares * price
                position = shares
                capital = 0
                trades.append({"date": date, "type": "BUY", "price": price, "shares": shares, "cost": cost})
                
            elif signal == -1 and position > 0:
                # Vender
                proceeds = position * price * (1 - self.commission)
                capital = proceeds
                pnl = proceeds - trades[-1]["cost"]
                trades.append({"date": date, "type": "SELL", "price": price, "pnl": pnl, "returns": pnl/trades[-1]["cost"]})
                position = 0
            
            # Calcular equity
            equity = capital + (position * price)
            equity_curve.append({"date": date, "equity": equity, "position": position > 0})
        
        # Cerrar posicion abierta al final
        if position > 0:
            proceeds = position * data["close"].iloc[-1] * (1 - self.commission)
            capital = proceeds
            pnl = proceeds - trades[-1]["cost"]
            trades.append({"date": data.index[-1], "type": "SELL", "price": data["close"].iloc[-1], "pnl": pnl})
        
        # Calcular metricas
        equity_df = pd.DataFrame(equity_curve)
        total_return = (capital - self.initial_capital) / self.initial_capital
        
        if len(trades) > 1:
            returns = [t.get("returns", 0) for t in trades if t["type"] == "SELL"]
            win_rate = sum(1 for r in returns if r > 0) / len(returns) if returns else 0
            avg_return = np.mean(returns) if returns else 0
            sharpe = (np.mean(returns) / np.std(returns)) * np.sqrt(365) if len(returns) > 1 and np.std(returns) > 0 else 0
        else:
            win_rate = 0
            avg_return = 0
            sharpe = 0
        
        # Max drawdown
        if not equity_df.empty:
            equity_df["peak"] = equity_df["equity"].cummax()
            equity_df["drawdown"] = (equity_df["equity"] - equity_df["peak"]) / equity_df["peak"]
            max_dd = equity_df["drawdown"].min()
        else:
            max_dd = 0
        
        return {
            "initial_capital": self.initial_capital,
            "final_capital": round(capital, 2),
            "total_return": round(total_return * 100, 2),
            "total_trades": len([t for t in trades if t["type"] == "SELL"]),
            "win_rate": round(win_rate * 100, 1),
            "avg_return": round(avg_return * 100, 2),
            "sharpe_ratio": round(sharpe, 2),
            "max_drawdown": round(max_dd * 100, 2),
            "trades": trades,
            "equity_curve": equity_curve
        }
```

---

## 4. Gestion de Riesgo

### 4.1 Position Size Calculator

Calcula el tamano optimo de posicion usando Kelly Criterion y Fixed %.

```python
def calculate_kelly(win_rate: float, avg_win: float, avg_loss: float) -> float:
    """Calcula el porcentaje optimo usando Kelly Criterion"""
    if avg_loss == 0:
        return 0
    b = avg_win / avg_loss  # Win/loss ratio
    p = win_rate
    q = 1 - p
    kelly = (p * b - q) / b
    return max(0, min(kelly, 0.25))  # Cap at 25% for safety

def calculate_position_size(capital: float, risk_percent: float, 
                           entry_price: float, stop_loss: float) -> dict:
    """Calcula tamano de posicion basado en riesgo"""
    risk_amount = capital * (risk_percent / 100)
    risk_per_unit = abs(entry_price - stop_loss)
    
    if risk_per_unit == 0:
        return {"error": "Stop loss igual al entry"}
    
    units = risk_amount / risk_per_unit
    position_value = units * entry_price
    position_pct = (position_value / capital) * 100
    
    return {
        "capital": capital,
        "risk_amount": round(risk_amount, 2),
        "risk_pct": risk_percent,
        "units": round(units, 4),
        "position_value": round(position_value, 2),
        "position_pct": round(position_pct, 1),
        "entry": entry_price,
        "stop_loss": stop_loss
    }

def calculate_stop_loss_atr(df: pd.DataFrame, multiplier: float = 2) -> float:
    """Calcula stop loss basado en ATR"""
    high, low, close = df["high"], df["low"], df["close"]
    tr = pd.concat([
        high - low,
        abs(high - close.shift(1)),
        abs(low - close.shift(1))
    ], axis=1).max(axis=1)
    atr = tr.rolling(14).mean().iloc[-1]
    return atr * multiplier

def risk_reward_ratio(entry: float, target: float, stop: float) -> dict:
    """Calcula relacion riesgo/recompensa"""
    risk = abs(entry - stop)
    reward = abs(target - entry)
    
    if risk == 0:
        return {"error": "Riesgo cero"}
    
    rr = reward / risk
    min_win_rate_needed = 1 / (1 + rr)
    
    return {
        "entry": entry,
        "target": target,
        "stop": stop,
        "risk": round(risk, 4),
        "reward": round(reward, 4),
        "rr_ratio": round(rr, 2),
        "min_win_rate": round(min_win_rate_needed * 100, 1)
    }
```

---

## 5. Bots de Trading

### 5.1 Binance Trading Bot (Paper Trading)

Bot de trading para Binance en modo paper trading.

```python
#!/usr/bin/env python3
"""
Binance Trading Bot - Bot de trading automatizado (paper trading)
"""
import requests, time, hmac, hashlib, json
from datetime import datetime
from typing import Optional

class PaperTradingBot:
    def __init__(self, symbol: str, initial_balance: float = 1000):
        self.symbol = symbol
        self.balance = initial_balance
        self.position = 0
        self.trades = []
        self.running = False
        self.api = "https://api.binance.com"
    
    def get_price(self) -> float:
        """Obtiene precio actual"""
        resp = requests.get(f"{self.api}/api/v3/ticker/price",
                          params={"symbol": self.symbol})
        return float(resp.json()["price"])
    
    def analyze(self) -> dict:
        """Analiza el mercado y decide que hacer"""
        # Obtener datos
        resp = requests.get(f"{self.api}/api/v3/klines",
                          params={"symbol": self.symbol, "interval": "1h", "limit": 50})
        klines = resp.json()
        closes = [float(k[4]) for k in klines]
        
        # RSI
        gains = []
        losses = []
        for i in range(1, len(closes)):
            change = closes[i] - closes[i-1]
            if change > 0:
                gains.append(change)
                losses.append(0)
            else:
                gains.append(0)
                losses.append(abs(change))
        
        avg_gain = sum(gains[-14:]) / 14 if len(gains) >= 14 else 0
        avg_loss = sum(losses[-14:]) / 14 if len(losses) >= 14 else 1
        rs = avg_gain / avg_loss if avg_loss > 0 else 50
        rsi = 100 - (100 / (1 + rs))
        
        # MA crossover
        ma_short = sum(closes[-10:]) / 10
        ma_long = sum(closes[-30:]) / 30
        
        signals = []
        if rsi < 30:
            signals.append("BUY_OVERSOLD")
        if rsi > 70:
            signals.append("SELL_OVERBOUGHT")
        if ma_short > ma_long and closes[-1] < ma_short:
            signals.append("BUY_MA_CROSS")
        if ma_short < ma_long and closes[-1] > ma_short:
            signals.append("SELL_MA_CROSS")
        
        return {
            "price": closes[-1],
            "rsi": round(rsi, 1),
            "ma_short": round(ma_short, 2),
            "ma_long": round(ma_long, 2),
            "signals": signals
        }
    
    def execute_decision(self, analysis: dict):
        """Ejecuta la decision de trading"""
        price = analysis["price"]
        signals = analysis["signals"]
        
        buy_signals = [s for s in signals if s.startswith("BUY")]
        sell_signals = [s for s in signals if s.startswith("SELL")]
        
        if buy_signals and self.balance > 0 and self.position == 0:
            # Comprar con 50% del balance
            invest = self.balance * 0.5
            shares = invest / price
            self.position = shares
            self.balance -= invest
            self.trades.append({
                "time": datetime.now().isoformat(),
                "type": "BUY", "price": price, "amount": invest, "shares": shares,
                "reason": buy_signals
            })
            return f"BUY {shares:.4f} @ {price:.2f} (${invest:.2f})"
        
        elif sell_signals and self.position > 0:
            # Vender toda la posicion
            proceeds = self.position * price
            pnl = proceeds - self.trades[-1]["amount"] if self.trades else 0
            self.balance += proceeds
            self.trades.append({
                "time": datetime.now().isoformat(),
                "type": "SELL", "price": price, "proceeds": proceeds, "pnl": pnl,
                "reason": sell_signals
            })
            self.position = 0
            return f"SELL @ {price:.2f} (PNL: ${pnl:.2f})"
        
        return "HOLD"
    
    def run(self, iterations: int = 10, interval: int = 60):
        """Ejecuta el bot durante N iteraciones"""
        self.running = True
        print(f"Paper Trading Bot iniciado - {self.symbol}")
        print(f"Balance inicial: ${self.balance:.2f}\n")
        
        for i in range(iterations):
            if not self.running:
                break
            
            analysis = self.analyze()
            decision = self.execute_decision(analysis)
            
            current_value = self.balance + (self.position * analysis["price"])
            
            print(f"[{i+1}/{iterations}] {datetime.now().strftime('%H:%M')} | "
                  f"Price: ${analysis['price']:.2f} | RSI: {analysis['rsi']} | "
                  f"Portfolio: ${current_value:.2f} | {decision}")
            
            time.sleep(interval)
        
        print(f"\nBot finalizado. Balance final: ${current_value:.2f}")
        pnl = current_value - 1000
        print(f"PNL total: ${pnl:.2f} ({pnl/1000*100:.1f}%)")
        return self.trades
```

---

## 6. Herramientas de Analisis

### 6.1 Market Sentiment Analyzer

Analiza el sentimiento de mercado basado en datos on-chain y redes sociales.

```python
#!/usr/bin/env python3
"""
Market Sentiment Analyzer - Analiza el sentimiento del mercado crypto
"""
import requests
import json
from datetime import datetime

class SentimentAnalyzer:
    """Analizador de sentimiento usando datos publicos"""
    
    def __init__(self):
        self.sources = {
            "fear_greed": "https://api.alternative.me/fng/",
            "bitcoin_dominance": "https://api.coingecko.com/api/v3/global",
        }
    
    def get_fear_greed_index(self) -> dict:
        """Obtiene el indice de miedo y codicia"""
        try:
            resp = requests.get(self.sources["fear_greed"], timeout=10)
            data = resp.json()
            latest = data["data"][0]
            return {
                "value": int(latest["value"]),
                "classification": latest["value_classification"],
                "timestamp": latest["timestamp"]
            }
        except Exception as e:
            return {"error": str(e)}
    
    def get_market_overview(self) -> dict:
        """Obtiene overview del mercado"""
        try:
            resp = requests.get(self.sources["bitcoin_dominance"], timeout=10)
            data = resp.json()["data"]
            return {
                "total_market_cap": data["total_market_cap"]["usd"],
                "btc_dominance": data["market_cap_percentage"]["btc"],
                "eth_dominance": data["market_cap_percentage"]["eth"],
                "market_cap_change": data["market_cap_change_percentage_24h_usd"]
            }
        except Exception as e:
            return {"error": str(e)}
    
    def analyze(self) -> dict:
        """Analisis completo de sentimiento"""
        fng = self.get_fear_greed_index()
        market = self.get_market_overview()
        
        interpretation = []
        
        if "value" in fng:
            if fng["value"] < 25:
                interpretation.append("EXTREME_FEAR - Posible oportunidad de compra")
            elif fng["value"] > 75:
                interpretation.append("EXTREME_GREED - Riesgo de correccion")
            elif fng["value"] < 40:
                interpretation.append("FEAR - Mercado pesimista")
            elif fng["value"] > 60:
                interpretation.append("GREED - Mercado optimista")
            else:
                interpretation.append("NEUTRAL - Sin senales claras")
        
        if "btc_dominance" in market:
            dom = market["btc_dominance"]
            if dom > 55:
                interpretation.append(f"BTC dominance {dom:.1f}% - Capital fleeing alts -> risk-off")
            elif dom < 40:
                interpretation.append(f"BTC dominance {dom:.1f}% - Alt season possible -> risk-on")
        
        return {
            "fear_greed": fng,
            "market_overview": market,
            "interpretation": interpretation,
            "timestamp": datetime.now().isoformat(),
            "overall": "BULLISH" if any("compra" in i.lower() for i in interpretation) 
                      else ("BEARISH" if any("venta" in i.lower() or "correccion" in i.lower() or "risk-off" in i.lower() for i in interpretation)
                      else "NEUTRAL")
        }
```

---

*Este PDF contiene scripts de muestra del Crypto Trading Toolkit.*
*El producto completo incluye herramientas completas de analisis, backtesting, bots de trading y gestion de riesgo.*

**Shirka AI - shirka-ai-store.company.site**
