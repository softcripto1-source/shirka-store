# DeepSeek Prompt Vault

**500 Prompts Expertos para desbloquear todo el potencial de DeepSeek AI**

---

## Contenido

- [1. Programacion y Desarrollo](#1-programacion-y-desarrollo)
- [2. Analisis de Datos](#2-analisis-de-datos)
- [3. Machine Learning](#3-machine-learning)
- [4. Creative Writing](#4-creative-writing)
- [5. Marketing y Copywriting](#5-marketing-y-copywriting)
- [6. Business Strategy](#6-business-strategy)
- [7. System Design](#7-system-design)
- [8. DevOps y Cloud](#8-devops-y-cloud)
- [9. Finanzas y Trading](#9-finanzas-y-trading)
- [10. Prompts Avanzados](#10-prompts-avanzados)

---

## 1. Programacion y Desarrollo

### REFACTORIZACION AUTOMATICA

Actua como un senior software engineer con 15 anos de experiencia. Analiza el siguiente codigo y sugiereme una refactorizacion completa que:
1. Mejore la legibilidad
2. Elimine code smells
3. Aplique principios SOLID
4. Anada type hints
5. Incluya docstrings

Explica CADA cambio que hagas y por que.

### CODE REVIEW PROFESIONAL

Eres un tech lead haciendo code review. Revisa este codigo y enumera:
1. Bugs potenciales
2. Problemas de rendimiento
3. Violaciones de seguridad
4. Mejoras de mantenibilidad
5. Sugerencias de testing

Puntua cada issue del 1 (critico) al 5 (cosmetico).

### GENERACION DE TESTS UNITARIOS

Genera tests unitarios completos para la siguiente funcion usando pytest. Incluye:
- Casos normales, casos borde, casos de error
- Mocks necesarios
- Fixtures y parametrizacion
- Cobertura minima: 95%

---

## 2. Analisis de Datos

### EXPLORACION AUTOMATIZADA

Actua como un data scientist senior. Toma este dataset y realizame un analisis exploratorio completo que incluya:
- Estadisticas descriptivas de cada variable
- Deteccion de outliers con IQR y Z-score
- Analisis de correlaciones (Pearson, Spearman)
- Distribuciones y histogramas
- Recomendaciones de preprocessing

Devuelve el analisis en formato interpretable, no solo codigo.

### PIPELINE DE LIMPIEZA

Disename un pipeline de limpieza de datos robusto que maneje:
- Valores nulos (imputacion estrategica)
- Duplicados
- Outliers
- Datos inconsistentes
- Normalizacion/escalado

Incluye validacion de calidad al final del pipeline.

### VISUALIZACION ESTRATEGICA

Tengo datos sobre [tema]. Recomiendame:
1. Que tipo de grafico usar para cada relacion
2. Variables mas relevantes a visualizar
3. Storytelling visual con los datos
4. Dashboard design para stakeholders

---

## 3. Machine Learning

### SELECCION DE MODELO

Tengo un problema de [clasificacion/regresion] con [N] muestras y [M] features. Recomiendame:
1. Algoritmos candidatos ordenados por idoneidad
2. Metricas de evaluacion apropiadas
3. Estrategia de validacion
4. Tecnicas de feature engineering
5. Hiperparametros iniciales para cada modelo

### OPTIMIZACION DE HIPERPARAMETROS

Disena una estrategia de hyperparameter tuning para [modelo] incluyendo:
- Grid search vs random search vs Bayesian
- Rango de valores para cada parametro
- Cross-validation strategy
- Early stopping criteria
- Comparacion de resultados

### INTERPRETACION DE MODELOS

Entrene un modelo de [tipo] con accuracy de [X]. Ayudame a interpretarlo:
1. Feature importance (SHAP, permutation)
2. Partial dependence plots
3. Individual predictions explanation
4. Bias detection
5. Limites del modelo

---

## 4. Creative Writing

### WORLD BUILDING

Ayudame a construir un mundo de ficcion para [genero]. Desarrolla:
1. Sistema de magia/tecnologia con reglas claras
2. Geopolitica y facciones
3. Historia y mitologia fundacional
4. Cultura, religion y conflictos
5. Personajes clave y sus motivaciones

### DIALOGO AUTENTICO

Escribe un dialogo entre [personaje A] y [personaje B] donde:
- Cada personaje tiene una voz unica
- Hay subtrama emocional no dicha
- El dialogo revela informacion sin exponerla directamente
- Hay tension creciente
- Cada linea de dialogo avanza la escena

### ESTRUCTURA NARRATIVA

Ayudame a estructurar mi novela/guion usando:
1. Three-act structure con puntos de giro
2. Arcos de personaje (interno y externo)
3. Subplots y su sincronizacion
4. Ritmo narrativo
5. Climax y resolucion

---

## 5. Marketing y Copywriting

### EMAIL SEQUENCE

Disena una secuencia de 5 emails para [producto/servicio] dirigida a [audiencia]:
1. Email de apertura con hook
2. Email de valor/educacion
3. Email de caso de uso/testimonio
4. Email de oferta con urgencia
5. Email de seguimiento/upsell

Cada email con subject line, preview text y cuerpo completo.

### LANDING PAGE COPY

Escribe el copy completo para una landing page de [producto] incluyendo:
- Hero headline con subheadline
- Social proof section
- Feature-benefit matrix
- Pricing section con psicologia de precios
- CTA button variants para A/B testing
- FAQ que anticipa objeciones

### SEO CONTENT BRIEF

Creame un content brief SEO para un articulo sobre [keyword]:
- Keyword cluster con LSI terms
- Search intent analysis
- Competitor gap analysis
- Outline con H1-H6 optimizados
- Pautas de E-E-A-T
- Meta title y description variants

---

## 6. Business Strategy

### BUSINESS MODEL CANVAS

Ayudame a completar un Business Model Canvas para [idea de negocio]:
1. Propuesta de valor unica
2. Segmentos de cliente
3. Canales de distribucion
4. Relacion con clientes
5. Fuentes de ingresos
6. Recursos clave
7. Actividades clave
8. Socios clave
9. Estructura de costes

### ANALISIS DE MERCADO

Realiza un analisis de mercado para [industria/segmento]:
- Tamano del mercado (TAM, SAM, SOM)
- Tendencias actuales y emergentes
- Competidores principales y sus estrategias
- Barreras de entrada
- Oportunidades de diferenciacion

### GO-TO-MARKET STRATEGY

Disena una estrategia go-to-market para [producto] en [mercado]:
1. Target customer profile detallado
2. Value proposition por segmento
3. Canales de adquisicion prioritarios
4. Pricing strategy
5. Launch timeline con hitos
6. KPIs de exito

---

## 7. System Design

### ARQUITECTURA ESCALABLE

Disena una arquitectura para un sistema que maneje [N] usuarios concurrentes:
- Componentes y sus responsabilidades
- Estrategia de escalado (horizontal/vertical)
- Base de datos (SQL vs NoSQL, sharding, replication)
- Caching strategy (CDN, Redis, Memcached)
- Message queues y event-driven architecture
- CAP theorem trade-offs

### API DESIGN

Disena una API REST/GraphQL para [sistema] considerando:
- Versioning strategy
- Rate limiting y throttling
- Autenticacion y autorizacion
- Error handling estandarizado
- Paginacion, filtrado y ordenamiento
- Documentacion con OpenAPI/Swagger
- Idempotencia y retry logic

### DATABASE DESIGN

Disena el esquema de base de datos para [aplicacion]:
1. Entidades y relaciones (ERD)
2. Indices estrategicos
3. Partition strategy
4. Backup y recovery plan
5. Migration strategy
6. Query optimization

---

## 8. DevOps y Cloud

### CI/CD PIPELINE

Disena un pipeline CI/CD completo para [proyecto] usando GitHub Actions/GitLab CI:
1. Build y lint
2. Tests unitarios y de integracion
3. Security scanning (SAST, DAST)
4. Docker image build y push
5. Deploy a [entorno]
6. Smoke tests post-deploy
7. Rollback strategy

### DOCKER COMPOSITION

Creame una configuracion Docker Compose para [stack tecnico]:
- Servicios con dependencias
- Volumes y networks
- Health checks
- Environment variables
- Resource limits
- Desarrollo vs produccion

### KUBERNETES DEPLOYMENT

Genera los manifestos Kubernetes para desplegar [aplicacion]:
- Deployments con rolling update
- Services (ClusterIP, LoadBalancer)
- ConfigMaps y Secrets
- HPA para autoescalado
- Ingress con TLS
- Network policies
- Pod resource requests/limits

---

## 9. Finanzas y Trading

### ANALISIS TECNICO

Realiza un analisis tecnico de [activo/par] en timeframe [X]:
- Soportes y resistencias clave
- Indicadores (RSI, MACD, Bollinger)
- Patrones de velas
- Volumen y price action
- Scenario analysis (alcista, bajista, lateral)

### ESTRATEGIA DE RIESGO

Disena un sistema de gestion de riesgo para trading con:
- Position sizing (Kelly Criterion / Fixed %)
- Stop loss strategy
- Take profit strategy
- Max drawdown limits
- Correlation aware portfolio
- Risk-adjusted metrics (Sharpe, Sortino)

### BACKTESTING FRAMEWORK

Creame un framework de backtesting para [estrategia] con:
- Data fetching y preprocessing
- Signal generation logic
- Trade execution simulation
- Performance metrics
- Walk-forward validation
- Monte Carlo simulation

---

## 10. Prompts Avanzados

### CHAIN-OF-THOUGHT

Resuelve el siguiente problema paso a paso usando chain-of-thought reasoning. Para cada paso, explica:
1. Que informacion tienes
2. Que estas asumiendo
3. Que estas calculando
4. Por que tomaste esa decision
5. Como verificas el resultado

### MULTI-STEP REASONING

Actua como un equipo de 3 expertos debatiendo este problema:
- Experto A: propone solucion principal
- Experto B: critica y encuentra fallos
- Experto C: sintetiza y propone solucion integrada
- Conclusion final con plan de accion

### RAG OPTIMIZATION

Disena un sistema RAG optimo para [caso de uso]:
1. Chunking strategy (tamano, overlap)
2. Embedding model selection
3. Vector database choice
4. Retrieval strategy (dense, sparse, hybrid)
5. Re-ranking pipeline
6. Prompt engineering para el LLM

---

*Este PDF contiene 25 prompts de muestra de las 10 categorias principales.*
*El producto completo incluye 500 prompts en 25 categorias en formato PDF y Markdown.*

**Shirka AI - shirka-ai-store.company.site**
