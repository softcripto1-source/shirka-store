# Dev Productivity Bundle

**40+ Scripts profesionales para automatizar tu flujo de trabajo y desarrollar 10x mas rapido**

---

## Contenido

1. Automatizacion de Entorno
2. DevOps y Despliegue
3. Procesamiento de Datos
4. Web Scraping y APIs
5. Utilidades de Productividad
6. Seguridad y Analisis
7. Testing y QA
8. Scripts de Sistema

---

## 1. Automatizacion de Entorno

### 1.1 Git Workflow Automator

Automatiza commits, branches, merges y PRs con mejores practicas.

```python
#!/usr/bin/env python3
"""
Git Workflow Automator - Automatiza operaciones git comunes
Uso: python git_automator.py [command] [options]
"""
import subprocess, sys, os
from datetime import datetime

def auto_commit(message=None):
    """Add all, commit with conventional commit format"""
    if not message:
        message = f"chore: auto-commit {datetime.now():%Y-%m-%d %H:%M}"
    subprocess.run(["git", "add", "-A"], check=True)
    subprocess.run(["git", "commit", "-m", message], check=True)
    print(f"[OK] Committed: {message}")

def create_feature_branch(name):
    """Create feature branch from main"""
    subprocess.run(["git", "checkout", "main"], check=True)
    subprocess.run(["git", "pull"], check=True)
    subprocess.run(["git", "checkout", "-b", f"feature/{name}"], check=True)
    print(f"[OK] Branch created: feature/{name}")

def sync_fork():
    """Sync fork with upstream"""
    subprocess.run(["git", "fetch", "upstream"], check=True)
    subprocess.run(["git", "checkout", "main"], check=True)
    subprocess.run(["git", "merge", "upstream/main"], check=True)
    subprocess.run(["git", "push"], check=True)
    print("[OK] Fork synced with upstream")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Comandos: commit, feature <name>, sync")
        sys.exit(1)
    
    cmd = sys.argv[1]
    if cmd == "commit":
        msg = sys.argv[2] if len(sys.argv) > 2 else None
        auto_commit(msg)
    elif cmd == "feature":
        create_feature_branch(sys.argv[2])
    elif cmd == "sync":
        sync_fork()
    else:
        print(f"Comando desconocido: {cmd}")
```

### 1.2 Python Virtual Environment Manager

Gestiona multiples entornos virtuales con un solo comando.

```python
#!/usr/bin/env python3
"""
Python Venv Manager - Crea, activa y gestiona entornos virtuales
"""
import subprocess, sys, os, json
from pathlib import Path

VENV_DIR = Path.home() / ".venvs"

def list_envs():
    """Lista todos los entornos disponibles"""
    if not VENV_DIR.exists():
        print("No hay entornos creados.")
        return
    for env_dir in VENV_DIR.iterdir():
        if env_dir.is_dir():
            size = sum(f.stat().st_size for f in env_dir.rglob('*'))
            print(f"  {env_dir.name} ({size // 1024**2} MB)")

def create_env(name, python="python3"):
    """Crea un nuevo entorno virtual"""
    env_path = VENV_DIR / name
    subprocess.run([python, "-m", "venv", str(env_path)], check=True)
    print(f"[OK] Entorno '{name}' creado en {env_path}")
    
    # Instalar paquetes base
    pip = str(env_path / "bin" / "pip")
    subprocess.run([pip, "install", "--upgrade", "pip"], check=True)
    subprocess.run([pip, "install", "ipython", "pytest"], check=True)
    print("[OK] Paquetes base instalados")

def install_requirements(name, req_file="requirements.txt"):
    """Instala requirements en un entorno"""
    env_path = VENV_DIR / name
    pip = str(env_path / "bin" / "pip")
    subprocess.run([pip, "install", "-r", req_file], check=True)
    print(f"[OK] Requirements instalados en '{name}'")

if __name__ == "__main__":
    cmds = {"list": list_envs, "create": lambda: create_env(sys.argv[2]),
            "install": lambda: install_requirements(sys.argv[2], sys.argv[3] if len(sys.argv)>3 else "requirements.txt")}
    cmd = sys.argv[1] if len(sys.argv) > 1 else "list"
    if cmd in cmds:
        cmds[cmd]()
    else:
        print(f"Uso: {sys.argv[0]} [list|create <name>|install <name> [req_file]]")
```

### 1.3 Docker Development Environment

Levanta entornos de desarrollo completos con un solo comando.

```yaml
version: '3.8'

services:
  app:
    build: .
    volumes:
      - .:/app
      - /app/node_modules
    ports:
      - "${PORT:-3000}:3000"
    environment:
      - NODE_ENV=development
      - DATABASE_URL=postgresql://user:pass@db:5432/devdb
    depends_on:
      - db
      - redis
    command: npm run dev

  db:
    image: postgres:16-alpine
    volumes:
      - pgdata:/var/lib/postgresql/data
    environment:
      POSTGRES_USER: user
      POSTGRES_PASSWORD: pass
      POSTGRES_DB: devdb
    ports:
      - "5432:5432"

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redisdata:/data

  test:
    build: .
    volumes:
      - .:/app
    command: npm test
    depends_on:
      - db
      - redis
    environment:
      - NODE_ENV=test
      - DATABASE_URL=postgresql://user:pass@db:5432/testdb

volumes:
  pgdata:
  redisdata:
```

### 1.4 Project Scaffolder

Genera la estructura completa de un proyecto nuevo en segundos.

```python
#!/usr/bin/env python3
"""
Project Scaffolder - Crea proyectos con estructura profesional
"""
import os, sys, json
from pathlib import Path

TEMPLATES = {
    "python-api": {
        "files": {
            "README.md": "# {name}\n\nAPI desarrollada con FastAPI\n",
            "requirements.txt": "fastapi\nuvicorn\nalembic\nsqlalchemy\npydantic\npytest\nhttpx\n",
            "app/__init__.py": "",
            "app/main.py": "from fastapi import FastAPI\n\napp = FastAPI(title=\"{name}\")\n\n@app.get(\"/health\")\nasync def health():\n    return {\"status\": \"ok\"}\n",
            "app/models.py": "from sqlalchemy import create_engine\nfrom sqlalchemy.orm import declarative_base\n\nBase = declarative_base()\n",
            "app/schemas.py": "from pydantic import BaseModel\n",
            "app/routes/__init__.py": "",
            "tests/__init__.py": "",
            "tests/test_api.py": "from fastapi.testclient import TestClient\nfrom app.main import app\n\nclient = TestClient(app)\n\ndef test_health():\n    response = client.get(\"/health\")\n    assert response.status_code == 200\n",
            "Dockerfile": "FROM python:3.11-slim\nWORKDIR /app\nCOPY requirements.txt .\nRUN pip install -r requirements.txt\nCOPY . .\nCMD [\"uvicorn\", \"app.main:app\", \"--host\", \"0.0.0.0\", \"--port\", \"8000\"]\n",
            ".env.example": "DATABASE_URL=sqlite:///dev.db\nDEBUG=true\n",
            ".gitignore": "__pycache__/\n*.pyc\n.env\nvenv/\n*.db\n",
        }
    },
    "react-app": {
        "files": {
            "README.md": "# {name}\n\nReact application\n",
            "package.json": '{{"name":"{name}","private":true,"scripts":{{"dev":"vite","build":"vite build","preview":"vite preview"}}}}\n',
            "index.html": "<!DOCTYPE html><html><head><title>{name}</title></head><body><div id=\"root\"></div><script type=\"module\" src=\"/src/main.jsx\"></script></body></html>",
            "src/main.jsx": "import React from 'react'\nimport ReactDOM from 'react-dom/client'\nimport App from './App'\n\nReactDOM.createRoot(document.getElementById('root')).render(\n  <React.StrictMode><App /></React.StrictMode>\n)\n",
            "src/App.jsx": "function App() {\n  return <div><h1>{name}</h1></div>\n}\nexport default App\n",
            "vite.config.js": "import {{ defineConfig }} from 'vite'\nimport react from '@vitejs/plugin-react'\n\nexport default defineConfig({{\n  plugins: [react()]\n}})\n",
            ".gitignore": "node_modules/\ndist/\n.env\n",
        }
    }
}

def scaffold(project_type, name):
    """Genera la estructura del proyecto"""
    base = Path(name)
    if base.exists():
        print(f"[ERROR] {name} ya existe")
        return
    
    template = TEMPLATES.get(project_type)
    if not template:
        print(f"[ERROR] Tipo desconocido: {project_type}")
        print(f"Disponibles: {list(TEMPLATES.keys())}")
        return
    
    for filepath, content in template["files"].items():
        full_path = base / filepath
        full_path.parent.mkdir(parents=True, exist_ok=True)
        formatted = content.format(name=name)
        full_path.write_text(formatted)
        print(f"  [OK] {filepath}")
    
    print(f"\n[OK] Proyecto '{name}' creado!")
    print(f"  cd {name}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(f"Uso: {sys.argv[0]} <tipo> <nombre>")
        print(f"Tipos: {list(TEMPLATES.keys())}")
        sys.exit(1)
    scaffold(sys.argv[1], sys.argv[2])
```

---

## 2. DevOps y Despliegue

### 2.1 CI/CD Pipeline Generator

Genera pipelines de CI/CD para GitHub Actions, GitLab CI y Jenkins.

```yaml
# .github/workflows/ci.yml - GitHub Actions Pipeline
name: CI/CD Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  quality:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: pip install -r requirements-dev.txt
      - run: ruff check .      # Linting
      - run: mypy .            # Type checking
      - run: pytest --cov=.    # Tests with coverage
      - run: safety check      # Security scan

  build:
    needs: quality
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build Docker image
        run: docker build -t app:${{ github.sha }} .
      - name: Scan for vulnerabilities
        uses: aquasecurity/trivy-action@master
        with:
          image-ref: 'app:${{ github.sha }}'
          format: 'sarif'
          output: 'trivy-results.sarif'

  deploy:
    needs: build
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to production
        run: |
          echo "Deploying ${{ github.sha }} to production..."
          # Aqui iria el deploy real
```

---

## 3. Procesamiento de Datos

### 3.1 Data Pipeline Framework

Framework para pipelines ETL con validacion y logging.

```python
#!/usr/bin/env python3
"""
Data Pipeline Framework - Procesamiento de datos con stages
"""
import pandas as pd
import numpy as np
from typing import Any, Callable, List, Dict
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)s | %(message)s')
logger = logging.getLogger(__name__)

class Pipeline:
    """Pipeline de datos con stages encadenables"""
    
    def __init__(self, name: str):
        self.name = name
        self.stages: List[Dict] = []
        self.data = None
    
    def add_stage(self, name: str, fn: Callable, **kwargs):
        """Anade un stage al pipeline"""
        self.stages.append({
            "name": name,
            "fn": fn,
            "kwargs": kwargs,
            "start": None,
            "end": None,
            "status": "pending"
        })
        return self
    
    def run(self, data: Any = None) -> Any:
        """Ejecuta todos los stages en orden"""
        result = data
        logger.info(f"Pipeline '{self.name}' iniciado ({len(self.stages)} stages)")
        
        for i, stage in enumerate(self.stages):
            stage["start"] = datetime.now()
            try:
                logger.info(f"  Stage {i+1}: {stage['name']}...")
                result = stage["fn"](result, **stage["kwargs"])
                stage["status"] = "completed"
                elapsed = (datetime.now() - stage["start"]).total_seconds()
                logger.info(f"  [OK] {stage['name']} ({elapsed:.2f}s)")
            except Exception as e:
                stage["status"] = "failed"
                logger.error(f"  [FAIL] {stage['name']}: {e}")
                raise
        
        logger.info(f"Pipeline '{self.name}' completado exitosamente")
        return result

# Ejemplos de stages
def load_csv(filepath: str) -> pd.DataFrame:
    logger.info(f"Cargando {filepath}")
    return pd.read_csv(filepath)

def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    logger.info("Limpiando datos...")
    df = df.drop_duplicates()
    df = df.dropna(thresh=len(df.columns) * 0.5)
    return df

def validate_schema(df: pd.DataFrame, expected_cols: list) -> pd.DataFrame:
    missing = [c for c in expected_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Columnas faltantes: {missing}")
    logger.info(f"Schema validado: {len(df.columns)} columnas")
    return df

# Uso: Pipeline("mi-pipeline").add_stage("carga", load_csv, filepath="data.csv").add_stage("clean", clean_data).run()
```

### 3.2 CSV to JSON Converter

Conversor inteligente de CSV a JSON con deteccion automatica de tipos.

```python
#!/usr/bin/env python3
"""
CSV to JSON Converter - Convierte CSV con deteccion de tipos automatica
"""
import csv, json, sys
from pathlib import Path
from datetime import datetime

def infer_type(value: str):
    """Detecta el tipo de dato automaticamente"""
    if not value or value.strip() == "":
        return None
    v = value.strip()
    
    # Booleano
    if v.lower() in ("true", "yes", "1"):
        return True
    if v.lower() in ("false", "no", "0"):
        return False
    
    # Entero
    try:
        return int(v)
    except ValueError:
        pass
    
    # Float
    try:
        return float(v.replace(",", "."))
    except ValueError:
        pass
    
    # Fecha
    for fmt in ["%Y-%m-%d", "%d/%m/%Y", "%Y-%m-%d %H:%M:%S", "%m/%d/%Y"]:
        try:
            return datetime.strptime(v, fmt).isoformat()
        except ValueError:
            pass
    
    # JSON
    if v.startswith("{") or v.startswith("["):
        try:
            return json.loads(v)
        except json.JSONDecodeError:
            pass
    
    return v

def convert(csv_path: str, output: str = None, pretty: bool = True):
    """Convierte CSV a JSON"""
    path = Path(csv_path)
    if not path.exists():
        print(f"[ERROR] Archivo no encontrado: {csv_path}")
        return
    
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            converted = {k: infer_type(v) for k, v in row.items()}
            rows.append(converted)
    
    if not output:
        output = path.with_suffix(".json")
    
    with open(output, "w", encoding="utf-8") as f:
        if pretty:
            json.dump(rows, f, indent=2, ensure_ascii=False)
        else:
            json.dump(rows, f, ensure_ascii=False)
    
    print(f"[OK] {len(rows)} registros convertidos: {output}")
    return output

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(f"Uso: {sys.argv[0]} <archivo.csv> [output.json]")
        sys.exit(1)
    convert(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
```

---

## 4. Web Scraping y APIs

### 4.1 Rate-Limited API Client

Cliente API con rate limiting, retry y cache.

```python
#!/usr/bin/env python3
"""
Rate-Limited API Client - Cliente con control de velocidad y reintentos
"""
import requests
import time
import hashlib
import json
from pathlib import Path
from functools import wraps
from typing import Optional, Callable

class APIClient:
    """Cliente API con rate limiting, retry y cache en disco"""
    
    def __init__(self, base_url: str, rate: int = 60, per_seconds: int = 60, cache_dir: str = ".api_cache"):
        self.base_url = base_url.rstrip("/")
        self.min_interval = per_seconds / rate
        self.last_call = 0
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
        self.session = requests.Session()
    
    def _cache_key(self, endpoint: str, params: dict = None) -> str:
        raw = f"{endpoint}:{json.dumps(params or {}, sort_keys=True)}"
        return hashlib.md5(raw.encode()).hexdigest()
    
    def _cache_get(self, key: str) -> Optional[dict]:
        cache_file = self.cache_dir / f"{key}.json"
        if cache_file.exists():
            return json.loads(cache_file.read_text())
        return None
    
    def _cache_set(self, key: str, data: dict):
        cache_file = self.cache_dir / f"{key}.json"
        cache_file.write_text(json.dumps(data))
    
    def _rate_limit(self):
        elapsed = time.time() - self.last_call
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self.last_call = time.time()
    
    def request(self, method: str, endpoint: str, use_cache: bool = True, max_retries: int = 3, **kwargs) -> dict:
        """Realiza una peticion con rate limiting y retry"""
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        params = kwargs.get("params")
        cache_key = self._cache_key(endpoint, params)
        
        if use_cache:
            cached = self._cache_get(cache_key)
            if cached:
                return cached
        
        for attempt in range(max_retries):
            self._rate_limit()
            try:
                response = self.session.request(method, url, timeout=30, **kwargs)
                response.raise_for_status()
                data = response.json()
                if use_cache:
                    self._cache_set(cache_key, data)
                return data
            except requests.exceptions.RequestException as e:
                if attempt == max_retries - 1:
                    raise
                wait = 2 ** attempt
                print(f"  Retry {attempt+1}/{max_retries} en {wait}s: {e}")
                time.sleep(wait)
    
    def get(self, endpoint: str, **kwargs):
        return self.request("GET", endpoint, **kwargs)
    
    def post(self, endpoint: str, **kwargs):
        return self.request("POST", endpoint, **kwargs)

# Uso
# client = APIClient("https://api.github.com", rate=30)
# data = client.get("/repos/owner/repo", params={"page": 1})
```

---

## 5. Utilidades de Productividad

### 5.1 File Organizer

Organiza archivos por tipo automaticamente.

```python
#!/usr/bin/env python3
"""
File Organizer - Organiza archivos en carpetas por tipo
"""
import os, shutil, sys, json
from pathlib import Path

EXTENSION_MAP = {
    "Imagenes": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp", ".ico"],
    "Documentos": [".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".md", ".csv"],
    "Videos": [".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm"],
    "Musica": [".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma"],
    "Archivos": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2"],
    "Codigo": [".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".cpp", ".c", ".h", ".rs", ".go", ".rb"],
    "Web": [".html", ".css", ".scss", ".sass", ".less", ".json", ".xml", ".yaml", ".yml"],
    "Instaladores": [".exe", ".msi", ".dmg", ".deb", ".rpm", ".AppImage"],
    "Discos": [".iso", ".img", ".vhd", ".vmdk"],
}

def organize(directory: str, dry_run: bool = False):
    """Organiza archivos en el directorio por extension"""
    base = Path(directory)
    if not base.exists():
        print(f"[ERROR] Directorio no existe: {directory}")
        return
    
    stats = {cat: 0 for cat in ["Otros"] + list(EXTENSION_MAP.keys())}
    
    for file in base.iterdir():
        if file.is_file() and not file.name.startswith("."):
            ext = file.suffix.lower()
            target = "Otros"
            for cat, exts in EXTENSION_MAP.items():
                if ext in exts:
                    target = cat
                    break
            
            target_dir = base / target
            stats[target] += 1
            
            if dry_run:
                print(f"  [DRY] {file.name} -> {target}/")
            else:
                target_dir.mkdir(exist_ok=True)
                dest = target_dir / file.name
                if dest.exists():
                    dest = target_dir / f"{file.stem}_{file.name}"
                shutil.move(str(file), str(dest))
    
    print(f"\nOrganizados {sum(stats.values())} archivos:")
    for cat, count in sorted(stats.items(), key=lambda x: -x[1]):
        if count > 0:
            print(f"  {cat}: {count}")

if __name__ == "__main__":
    organize(sys.argv[1] if len(sys.argv) > 1 else ".", "--dry" in sys.argv)
```

### 5.2 Time Tracker

Seguimiento de tiempo con reportes automaticos.

```python
#!/usr/bin/env python3
"""
Time Tracker - Registro de tiempo con reportes diarios
"""
import time, json, sys
from pathlib import Path
from datetime import datetime, timedelta

DATA_FILE = Path.home() / ".timetracker.json"

def load_data() -> dict:
    if DATA_FILE.exists():
        return json.loads(DATA_FILE.read_text())
    return {"sessions": [], "projects": {}}

def save_data(data: dict):
    DATA_FILE.write_text(json.dumps(data, indent=2))

def start(project: str, task: str):
    data = load_data()
    data["sessions"].append({
        "project": project,
        "task": task,
        "start": datetime.now().isoformat(),
        "end": None
    })
    save_data(data)
    print(f"[OK] Tracking started: {project}/{task}")

def stop():
    data = load_data()
    for session in reversed(data["sessions"]):
        if session["end"] is None:
            session["end"] = datetime.now().isoformat()
            start_t = datetime.fromisoformat(session["start"])
            end_t = datetime.fromisoformat(session["end"])
            duration = (end_t - start_t).total_seconds() / 60
            print(f"[OK] Session ended: {session['project']}/{session['task']} ({duration:.1f} min)")
            save_data(data)
            return
    print("[WARN] No active session found")

def report(days: int = 7):
    data = load_data()
    cutoff = datetime.now() - timedelta(days=days)
    
    by_project = {}
    for s in data["sessions"]:
        if s["end"]:
            start_t = datetime.fromisoformat(s["start"])
            if start_t > cutoff:
                project = s["project"]
                mins = (datetime.fromisoformat(s["end"]) - start_t).total_seconds() / 60
                by_project[project] = by_project.get(project, 0) + mins
    
    print(f"\nTime Report (last {days} days):")
    print("-" * 40)
    for project, mins in sorted(by_project.items(), key=lambda x: -x[1]):
        hours = mins / 60
        print(f"  {project}: {hours:.1f}h ({mins:.0f} min)")
    total = sum(by_project.values()) / 60
    print(f"\n  Total: {total:.1f}h")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: timetracker.py [start <project> <task> | stop | report <days>]")
        sys.exit(1)
    
    cmd = sys.argv[1]
    if cmd == "start" and len(sys.argv) >= 4:
        start(sys.argv[2], sys.argv[3])
    elif cmd == "stop":
        stop()
    elif cmd == "report":
        days = int(sys.argv[2]) if len(sys.argv) > 2 else 7
        report(days)
    else:
        print(f"Comando desconocido: {cmd}")
```

---

## 6. Seguridad y Analisis

### 6.1 Password Strength Checker

Analizador de fortaleza de contrasenas con recomendaciones.

```python
#!/usr/bin/env python3
"""
Password Strength Checker - Evaluacion de seguridad de contrasenas
"""
import re, math, sys

def check_password(password: str) -> dict:
    """Evalua la fortaleza de una contrasena"""
    score = 0
    feedback = []
    
    # Longitud
    length = len(password)
    if length >= 16:
        score += 30
    elif length >= 12:
        score += 20
    elif length >= 8:
        score += 10
    else:
        feedback.append("La contrasena es demasiado corta (min 8 caracteres)")
    
    # Mayusculas
    if re.search(r'[A-Z]', password):
        score += 15
    else:
        feedback.append("Anade al menos una mayuscula")
    
    # Minusculas
    if re.search(r'[a-z]', password):
        score += 10
    else:
        feedback.append("Anade al menos una minuscula")
    
    # Numeros
    if re.search(r'\d', password):
        score += 15
    else:
        feedback.append("Anade al menos un numero")
    
    # Simbolos
    if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        score += 20
    else:
        feedback.append("Anade al menos un simbolo especial")
    
    # Variedad de caracteres unicos
    unique = len(set(password))
    entropy = unique * math.log2(length) if length > 0 else 0
    
    if entropy > 60:
        score += 10
    elif entropy < 30:
        feedback.append("Usa una mayor variedad de caracteres")
    
    # Patrones comunes
    common = ["password", "123456", "qwerty", "admin", "letmein", "welcome"]
    if any(p in password.lower() for p in common):
        score -= 30
        feedback.append("Evita patrones comunes")
    
    # Patrones de teclado
    if re.search(r'(?:abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno)', password.lower()):
        score -= 15
        feedback.append("Evita secuencias de teclado consecutivas")
    
    score = max(0, min(100, score))
    
    if score >= 80: strength = "MUY FUERTE"
    elif score >= 60: strength = "FUERTE"
    elif score >= 40: strength = "MODERADA"
    elif score >= 20: strength = "DEBIL"
    else: strength = "MUY DEBIL"
    
    return {
        "score": score,
        "strength": strength,
        "length": length,
        "entropy": round(entropy, 1),
        "feedback": feedback
    }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        pwd = input("Contrasena: ")
    else:
        pwd = sys.argv[1]
    
    result = check_password(pwd)
    print(f"\nFortaleza: {result['strength']} ({result['score']}/100)")
    print(f"Entropia: {result['entropy']} bits")
    if result['feedback']:
        print(f"\nRecomendaciones:")
        for fb in result['feedback']:
            print(f"  - {fb}")
```

---

*Este PDF contiene scripts de muestra representativos.*
*El producto completo incluye 40+ scripts en Python, Bash, Node.js y PowerShell con documentacion completa.*

**Shirka AI - shirka-ai-store.company.site**
